import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  @Input() numberOfResearch: number = 0;
  @Input() score: number = 0;

  constructor() { }

  ngOnInit() { }

}

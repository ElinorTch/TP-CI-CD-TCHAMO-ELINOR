export interface IRegion {
  region: string;
}

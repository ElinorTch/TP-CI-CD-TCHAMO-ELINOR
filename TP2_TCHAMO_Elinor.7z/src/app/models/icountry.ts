export interface ICountry {
  nom: string;
  name : string;
  population : number;
  flag : string;
  capital : string;
  subregion : string;
}

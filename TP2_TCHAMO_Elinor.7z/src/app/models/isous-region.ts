export interface ISousRegion {
  subregion: string;
  region: string;
}
